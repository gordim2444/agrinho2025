let nave;
let obstaculos = [];
let bonus = [];
let pontuacao = 0;
let vida = 3;
let gameOver = false;

let imgNave;
let imgAsteroide;
let imgVida;
let imgPonto;

let somColisao;
let somColeta;
let somGameOver;

function preload() {
  // Carregue suas imagens e sons aqui
  // Por exemplo:
  // imgNave = loadImage('assets/nave.png');
  // imgAsteroide = loadImage('assets/asteroide.png');
  // imgVida = loadImage('assets/vida.png');
  // imgPonto = loadImage('assets/ponto.png');

  // Para fins de demonstração, vamos usar formas, mas sinta-se à vontade para adicionar imagens!

  // somColisao = loadSound('assets/colisao.mp3');
  // somColeta = loadSound('assets/coleta.mp3');
  // somGameOver = loadSound('assets/gameover.mp3');
}

function setup() {
  createCanvas(800, 600);
  nave = new Nave();
  rectMode(CENTER); // Desenha retângulos do centro para facilitar colisões
  ellipseMode(CENTER); // Desenha círculos do centro

  // Inicia a geração de obstáculos e bônus
  setInterval(gerarObstaculo, 1000); // Gera um obstáculo a cada 1 segundo
  setInterval(gerarBonus, 3000);    // Gera um bônus a cada 3 segundos
}

function draw() {
  background(0); // Fundo preto do espaço

  if (!gameOver) {
    // Atualiza e exibe a nave
    nave.update();
    nave.display();

    // Atualiza, exibe e verifica colisões dos obstáculos
    for (let i = obstaculos.length - 1; i >= 0; i--) {
      obstaculos[i].update();
      obstaculos[i].display();

      if (nave.colide(obstaculos[i])) {
        vida--;
        // if (somColisao) somColisao.play();
        obstaculos.splice(i, 1); // Remove o obstáculo colidido
        if (vida <= 0) {
          gameOver = true;
          // if (somGameOver) somGameOver.play();
        }
      } else if (obstaculos[i].offScreen()) {
        obstaculos.splice(i, 1); // Remove obstáculos que saíram da tela
      }
    }

    // Atualiza, exibe e verifica colisões dos bônus
    for (let i = bonus.length - 1; i >= 0; i--) {
      bonus[i].update();
      bonus[i].display();

      if (nave.colide(bonus[i])) {
        // if (somColeta) somColeta.play();
        if (bonus[i].tipo === 'ponto') {
          pontuacao += 10;
        } else if (bonus[i].tipo === 'vida') {
          vida++;
        }
        bonus.splice(i, 1); // Remove o bônus coletado
      } else if (bonus[i].offScreen()) {
        bonus.splice(i, 1); // Remove bônus que saíram da tela
      }
    }

    // Exibe a pontuação e a vida
    fill(255);
    textSize(24);
    text(`Pontuação: ${pontuacao}`, 10, 30);
    text(`Vida: ${vida}`, 10, 60);

    // Incrementa a pontuação continuamente (tempo de sobrevivência)
    pontuacao += 0.1;

  } else {
    // Tela de Game Over
    fill(255, 0, 0);
    textSize(64);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 50);
    textSize(32);
    text(`Sua Pontuação Final: ${floor(pontuacao)}`, width / 2, height / 2 + 20);
    textSize(24);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 80);
  }
}

function keyPressed() {
  if (gameOver && key === 'r' || key === 'R') {
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  nave = new Nave();
  obstaculos = [];
  bonus = [];
  pontuacao = 0;
  vida = 3;
  gameOver = false;
}

function gerarObstaculo() {
  if (!gameOver) {
    let x = random(width);
    let y = -20; // Começa acima da tela
    let tipo = floor(random(2)); // 0 para asteroide, 1 para inimigo (exemplo)
    obstaculos.push(new Obstaculo(x, y, tipo));
  }
}

function gerarBonus() {
  if (!gameOver) {
    let x = random(width);
    let y = -20; // Começa acima da tela
    let tipo = random() < 0.7 ? 'ponto' : 'vida'; // 70% de chance de ser ponto, 30% de ser vida
    bonus.push(new Bonus(x, y, tipo));
  }
}

// Classe Nave
class Nave {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.tamanho = 40;
    this.velocidade = 8; // Velocidade de movimento
  }

  update() {
    // Controle da nave com o mouse
    this.x = mouseX;
    // Garante que a nave não saia da tela lateralmente
    this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);

    // Se preferir controle por teclado:
    // if (keyIsDown(LEFT_ARROW)) {
    //   this.x -= this.velocidade;
    // }
    // if (keyIsDown(RIGHT_ARROW)) {
    //   this.x += this.velocidade;
    // }
    // this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);
  }

  display() {
    fill(0, 0, 255); // Cor da nave (azul)
    if (imgNave) {
      image(imgNave, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
    } else {
      triangle(this.x, this.y - this.tamanho / 2,
               this.x - this.tamanho / 2, this.y + this.tamanho / 2,
               this.x + this.tamanho / 2, this.y + this.tamanho / 2);
    }
  }

  colide(objeto) {
    // Colisão simples baseada na distância (para círculos/quadrados)
    // Para formas mais complexas, você precisaria de colisões mais precisas.
    let d = dist(this.x, this.y, objeto.x, objeto.y);
    return d < (this.tamanho / 2 + objeto.tamanho / 2);
  }
}

// Classe Obstaculo
class Obstaculo {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.velocidade = random(2, 5); // Velocidade de queda
    this.tamanho = random(20, 50);
    this.tipo = tipo; // Pode ser 'asteroide', 'inimigo', etc.
  }

  update() {
    this.y += this.velocidade;
  }

  display() {
    if (this.tipo === 0) { // Asteroide
      fill(100); // Cinza
      if (imgAsteroide) {
        image(imgAsteroide, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
      } else {
        ellipse(this.x, this.y, this.tamanho);
      }
    } else if (this.tipo === 1) { // Inimigo (exemplo)
      fill(255, 0, 0); // Vermelho
      rect(this.x, this.y, this.tamanho * 0.8, this.tamanho * 1.2);
    }
  }

  offScreen() {
    return this.y > height + this.tamanho;
  }
}

// Classe Bonus
class Bonus {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.velocidade = random(1, 3); // Velocidade de queda
    this.tamanho = 30;
    this.tipo = tipo; // 'ponto' ou 'vida'
  }

  update() {
    this.y += this.velocidade;
  }

  display() {
    if (this.tipo === 'ponto') {
      fill(0, 255, 0); // Verde (para pontos)
      if (imgPonto) {
        image(imgPonto, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
      } else {
        star(this.x, this.y, this.tamanho * 0.4, this.tamanho * 0.8, 5); // Uma estrela como ponto
      }
    } else if (this.tipo === 'vida') {
      fill(255, 255, 0); // Amarelo (para vida)
      if (imgVida) {
        image(imgVida, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
      } else {
        rect(this.x, this.y, this.tamanho, this.tamanho); // Um quadrado como vida
      }
    }
  }

  offScreen() {
    return this.y > height + this.tamanho;
  }
}

// Função auxiliar para desenhar uma estrela (usada para o bônus de ponto)
function star(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}